<?php
include("./classes/DB.php");
include("./classes/functional.php");
include("./layout.php");
